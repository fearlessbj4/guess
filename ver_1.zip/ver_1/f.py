def result(g,a):
	r=[0,0,0,0,0]
	sr=""
	for i in range(len(g)):
		if(a.find(g[i])==-1):
			r[i]=-1
		elif(a.find(g[i])!=-1):
			if(a[i]==g[i]):
				r[i]=1
			else:
				r[i]=0
	for i in range(5):
		sr+=("a" if r[i]==1 else "b" if r[i]!=-1 else "c")
	return sr