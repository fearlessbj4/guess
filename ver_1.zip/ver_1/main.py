from answer import *
from f import result
import json
import random

total=0
file = json.load(open("./pre.json","r"))
tree=file['pre_guess']
guess="abase"
guess1=guess
answer=ans
time=0

r=result(answer,guess)
#"""
print(r)
temp=[]
temp2=[]

for i in range(len(dictionary)):
	if(r==tree[i+2315*dictionary.index(guess)]):
		#total+=1
		temp.append(i)
		#temp.append(dictionary[i])
#print(temp)
if(len(temp)<=2 and len(temp)>0):
	for i in range(len(temp)):
		if(result(dictionary[temp[i]],answer)=="aaaaa"):
		  #print("answer is :"+dictionary[temp[i]])
		  guess=dictionary[temp[i]]
		  time=1+(i+1)
		  break


else:
	temp1=len(temp)
	for j in range(0,2):
		temp2=[]
		guess=dictionary[temp[j]]
		r2=result(guess,answer)
		for i in range(len(dictionary)):
			if(r2==tree[i+2315*dictionary.index(guess)]):
				# total+=1
				#print(r2)
				temp2.append(dictionary[i])
				temp.append(dictionary[i])
		print(temp2)
		guess=max(set(temp),key=temp.count)
		#for i in range(len(dictionary)):
		#	if(r2==tree[i*2315+dictionary.index(guess)]):
				#total+=1
				#print(r2)
		#		temp2.append(dictionary[i])
		#		temp.append(dictionary[i])
		#print(temp2)
	#guess=max(set(temp),key=temp.count)
	#print(guess)
	#print(temp1)
	
	#time=2+1

print(guess)
print(time)