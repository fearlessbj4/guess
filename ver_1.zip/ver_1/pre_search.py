import json
from f import result
from answer import dictionary
lst=[]

for gi in range(len(dictionary)):
	g=dictionary[gi]
	for i in range(len(dictionary)):
		lst.append(result(g,dictionary[i]))
		#print(result(g,dictionary[i]))
file= open("pre.json","w")
json.dump({"pre_guess":lst},file)
file.close()